ci.fun <- function(x1, x2, n1, n2, alternative = "two.sided") {
  P1 <- x1/n1
  P2 <- x2/n2
  v_P1 <- (P1 * (1 - P1))/n1
  v_P2 <- (P2 * (1 - P2))/n2
  d <- P2 - P1
  SE_d <- sqrt(v_P1 + v_P2)

  if (alternative == "two.sided") {
    z <- qnorm(1 - 0.025)
    ci_low <- d - z * SE_d
    ci_upp <- d + z * SE_d
    t_vec <- d / SE_d
    pv_vec <- 2 * pnorm(-abs(t_vec))
  } else if (alternative == "greater") {
    z <- qnorm(0.05)
    ci_low <- -Inf
    ci_upp <- d + z * SE_d
    t_vec <- d / SE_d
    pv_vec <- pnorm(t_vec)
  } else if (alternative == "less") {
    z <- qnorm(0.95)
    ci_low <- d - z * SE_d
    ci_upp <- Inf
    t_vec <- d / SE_d
    pv_vec <- 1 - pnorm(t_vec)
  } else {
    stop("Invalid alternative type. Must be 'two.sided', 'less', or 'greater'.")
  }

  return(list(x1 = x1, x2 = x2, n1 = n1, n2 = n2, P1 = P1, P2 = P2,
              v_P1 = v_P1, v_P2 = v_P2, d = d, ci_low = ci_low, ci_upp = ci_upp, pv_vec = pv_vec))
}

lfi <- function(x1,x2,n1,n2,lambda){
  LR <- function(x1, x2) {
    sigma_hat2 <- x1 / (n1^2) * (1 - x1 / n1) + x2 / (n2^2) * (1 - x2 / n2)
    LR_value <- exp(-((x1 / n1 - x2 / n2)^2) / (2 * sigma_hat2))
    return(LR_value)
  }
  if(LR(x1,x2) < lambda){
    i <- 0
    lr_value <- LR(x1,x2)
    while(lr_value < lambda){
      if(x1/n1 < x2/n2){
        i <- i + 1
        x1_new <- x1 + i
        lr_value <- LR(x1_new,x2)
      }
      else if(x1/n1 >= x2/n2){
        i <- i + 1
        x2_new <- x2 + i
        lr_value <- LR(x1,x2_new)
      }
      if (lr_value >= lambda || i >= n1) {
        break
      }

    }
    return(i)
  }
  else if(LR(x1,x2) >= lambda){
    i <- 0
    lr_value <- LR(x1,x2)
    while(lr_value >= lambda){
      if(x1/n1 < x2/n2){
        i <- i + 1
        x1_new <- x1 - i
        lr_value <- LR(x1_new,x2)
      }
      else if(x1/n1 >= x2/n2){
        i <- i + 1
        x2_new <- x2 - i
        lr_value <- LR(x1,x2_new)
      }
      if (lr_value < lambda || i >= n1) {
        break
      }
    }
    return(-i)
  }
}


LR <- function(x1, x2, n1, n2) {
  sigma_hat2 <- x1 / (n1^2) * (1 - x1 / n1) + x2 / (n2^2) * (1 - x2 / n2)
  LR_value <- exp(-((x1 / n1 - x2 / n2)^2) / (2 * sigma_hat2))
  return(LR_value)
}

lr.fun <- function(x1,x2,n1,n2){
  ((n1/(n1+n2))^n1)*((n2/(n1+n2))^n2)*((1+x2/x1)^x1)*((1+x1/x2)^x2)*
    ((1+((n2-x2)/(n1-x1)))^(n1-x1))*((1+((n1-x1)/(n2-x2)))^(n2-x2))
}

lsi <- function(x1,x2,n1,n2,lfi){
  LR <- function(x1, x2, n1, n2) {
    sigma_hat2 <- x1 / (n1^2) * (1 - x1 / n1) + x2 / (n2^2) * (1 - x2 / n2)
    LR_value <- exp(-((x1 / n1 - x2 / n2)^2) / (2 * sigma_hat2))
    return(LR_value)
  }
  if(lfi>=0){
    if(x1/n1<=x2/n2){
      lsi <- 1-sqrt(log(LR(x1+lfi,x2,n1,n2))/log(LR(x1,x2,n1,n2)))
    }
    else if(x1/n1>x2/n2){
      lsi <- 1-sqrt(log(LR(x1,x2+lfi,n1,n2))/log(LR(x1,x2,n1,n2)))
    }
  }
  else if(lfi<0){
    if(x1/n1<=x2/n2){
      lsi <- 1-sqrt(log(LR(x1,x2,n1,n2))/log(LR(x1+lfi,x2,n1,n2)))
    }
    else if(x1/n1>x2/n2){
      lsi <- 1-sqrt(log(LR(x1,x2,n1,n2))/log(LR(x1,x2+lfi,n1,n2)))
    }
  }
  return(lsi)
}

lsi.one.sided <- function(x1,x2,n1,n2,lfi,alternative="less"){
  if (alternative == "less"){
    LR <- function(x1, x2, n1, n2) {
      sigma_hat2 <- x1 / (n1^2) * (1 - x1 / n1) + x2 / (n2^2) * (1 - x2 / n2)
      LR_value <- exp(-((x1 / n1 - x2 / n2)^2) / (2 * sigma_hat2))
      return(LR_value)
    }
    if(lfi>=0){
      if(x1/n1<=x2/n2){
        lsi <- 1-sqrt(log(LR(x1+lfi,x2,n1,n2))/log(LR(x1,x2,n1,n2)))
      }
      else if(x1/n1>x2/n2){
        lsi <- 1-sqrt(log(LR(x1,x2+lfi,n1,n2))/log(LR(x1,x2,n1,n2)))
      }
    }
    else if(lfi<0){
      if(x1/n1<=x2/n2){
        lsi <- 1-sqrt(log(LR(x1,x2,n1,n2))/log(LR(x1+lfi,x2,n1,n2)))
      }
      else if(x1/n1>x2/n2){
        lsi <- 1-sqrt(log(LR(x1,x2,n1,n2))/log(LR(x1,x2+lfi,n1,n2)))
      }
    }
    return(lsi)
  }
 else if (alternative=="greater"){
   1
 }
}


si.fun <- function(p,a) {
  if(p < a | p == a){
    1-(qnorm(1-(a/2))/qnorm(1-(p/2)))
  } else {
    1-(qnorm(1-(p/2))/qnorm(1-(a/2)))
  }
}

si.fun.one.sided <- function(p,a,alternative="less") {
  if (alternative == "less"){
    if(p < a | p == a){
      1-(qnorm(1-(a))/qnorm(1-(p)))
    } else if((a < p) & (p < 0.5)) {
      1-(qnorm(1-(p))/qnorm(1-(a)))
    }
    else{
      1
    }
  }else if (alternative == "greater"){
    1
  }
}


ci.odds.fun <- function(x1, x2, n1, n2, alternative = "two.sided") {
  P1 <- x1/n1
  P2 <- x2/n2
  logodds <- log((x1*(n2-x2))/(x2*(n1-x1)))
  odds <- exp(logodds)
  SE <- sqrt(1/x1 + 1/(n1-x1) + 1/x2 + 1/(n2-x2))

  if (alternative == "two.sided") {
    z <- qnorm(1 - 0.025)
    ci_low <- exp(logodds - z * SE)
    ci_upp <- exp(logodds + z * SE)
    z_vec <- logodds / SE
    pv_vec <- 2 * pnorm(-abs(z_vec))
  } else if (alternative == "greater") {
    z <- qnorm(0.05)
    ci_low <- 0
    ci_upp <- exp(logodds + z * SE)
    z_vec <- logodds / SE
    pv_vec <- pnorm(z_vec)
  } else if (alternative == "less") {
    z <- qnorm(0.95)
    ci_low <- exp(logodds - z * SE)
    ci_upp <- Inf
    z_vec <- logodds / SE
    pv_vec <- 1 - pnorm(z_vec)
  } else {
    stop("Invalid alternative type. Must be 'two.sided', 'less', or 'greater'.")
  }

  return(list(x1 = x1, x2 = x2, n1 = n1, n2 = n2, P1 = P1, P2 = P2,
              odds = odds, SE = SE, ci_low = ci_low, ci_upp = ci_upp, pv_vec = pv_vec))
}

boot_diff_prop <- function(x1, x2, n1, n2, n_boot) {
  # Define a function to calculate the difference in proportions
  diff_prop <- function(x, y) {
    prop1 <- sum(x) / length(x)
    prop2 <- sum(y) / length(y)
    return(prop1 - prop2)
  }

  # Calculate the observed difference in proportions
  obs_diff <- diff_prop(x1/n1, x2/n2)

  # Generate bootstrap samples
  boot_samples_1 <- replicate(n_boot, sample(x1, size = n1, replace = TRUE))
  boot_samples_2 <- replicate(n_boot, sample(x2, size = n2, replace = TRUE))

  # Calculate the difference in proportions for each bootstrap sample
  boot_diffs <- apply(boot_samples_1, 2, function(x) apply(boot_samples_2, 2, diff_prop, x))

  # Calculate the bootstrap percentile confidence intervals
  lower <- quantile(boot_diffs, 0.025)
  upper <- quantile(boot_diffs, 0.975)

  # Calculate the p-value
  #The p-value of a two-sided test for the difference in proportions
  #is two times the minimum of the proportion of bootstrap samples
  #where the difference in proportions is greater than or equal
  #to the observed difference and the proportion of bootstrap samples where the difference
  #in proportions is less than or equal to the observed difference.
  p_value <- 2 * min(c(mean(boot_diffs >= obs_diff), mean(boot_diffs <= obs_diff)))

  return(list(lower = lower, upper = upper, p_value = p_value))
}

q.fun <- function(x1,x2,n1,n2,p,a,alternative = "two.sided"){
  if (alternative == "two.sided") {
    sigma <-sqrt((x1/n1^2)*(1-x1/n1)+(x2/n2^2)*(1-x2/n2))
    Q <- (qnorm(1-p/2)-(qnorm(1-a/2)))*sigma
    FI_st <- Q*n1
    return(c(Q,FI_st))
  } else if (alternative == "less") {
    sigma <-sqrt((x1/n1^2)*(1-x1/n1)+(x2/n2^2)*(1-x2/n2))
    Q <- (qnorm(1-p)-(qnorm(1-a)))*sigma
    FI_st <- Q*n1
    return(c(Q,FI_st))
  }
}


